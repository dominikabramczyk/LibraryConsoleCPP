#include "Employee.h"
#include "User.h"
#include <string>
#include <iostream>
using namespace std;

string name, surename;
Employee::Employee(string n/*name*/, string s/*surename*/)
{
	name = n;
	surename = s;
};

void Employee::add_user()
{
	cout << "\tWitaj w rejestracji pracownikow!\nPodaj imie: ";
	cin >> name;
	cout << "Podaj nazwisko: ";
	cin >> surename;
	cout << name << " " << surename << "Zostal zajerestrowany" << "\n\n\n";
};

 