﻿#include <iostream>
#include "Employee.h"
#include "User.h"
#include "Student.h"
#include "Book.h"
#include <conio.h>
#include <stdio.h>
#include <string.h>
#include <cstdlib>
using namespace std;

	/*char name1{ 1 }, name2{ 2 };

void login_checking (name1,name2)
{
	int i, jest;
	char login[16];
	char loginy[11][16] =
	{
						{"Tomasz"},
						{"Adam"},
						{"Jacek"},
						{"Stanislaw"},
						{"Eustachy"},
						{"Anna"},
						{"Jarek"},
						{"Janusz"},
						{"Czeslaw"},
						{name1},
						{name2},
	};
	cout << ("Podaj swoj login: ");
	cin >> ("%s", login);
	jest = 0;
	i = 0;
	do
	{
		if (strcmp(login, loginy[i]) == 0)
		{
			system("cls");
			cout << ("Znaleziono uzytkownika");
			jest = 1;
		}
		else
		{
			cout << ("Nie znam Cie");

			i++;
		}
	} while (jest == 0);
}*/



int main()
{
	int a; // a - variable  to switch
	cout << "-*-*-*-*-*-*-*-*-*\n\tMENU\n-*-*-*-*-*-*-*-*-*\n\n1.Rejestracja studentow\n2.Rejestracja pracownikow\n3.Dodaj nowa ksiazke\n4.Wypozycz ksiazke\n5.Oddaj ksiazke\n6.Zamknij program\n\n";
	cin >> a;
	system("cls");

	switch (a)
	{
	      case 1: { //Rejestracja studentow
			  Student S("Imie", "Nazwisko");
			  User *wsk;
			  wsk = &S;
			  wsk->add_user();
	      }break;
		  case 2: { //Rejestracja pracownikow
			  Employee E("Imie", "Nazwisko");
			  User *wsk;
			  wsk = &E;
			  wsk->add_user();
			  
		  }break;
		  //case 3: { //logowanie

			 // //login_checking();

		  //}break;
		  case 3: { //Dodaj nowa ksiazke
			  Book B("Title", 0/*ilosc*/);
			  B.add_book();
	
		  }break;
		  case 4: { //Wypozycz ksiazke
			  Book A("Title", 0);
			  A.rent_book();

		  }break;
		  case 5: { //oddawanie ksiazek
			  Book C("Title", 0);
			  C.return_book();
		  }break;
		  case 6: {
			  cout << "\n\n\tDziekujemy za skorzystanie z naszych uslug!!\n\n\n\n\n";
			  exit(0);
		  }break;

		  default: {
			  cout << "Wybrano nie poprawna instrukcje";
		  }
		break;
	}

	cout << "\n\n\tDziekujemy za skorzystanie z naszych uslug!!\n\n\n\n\n";

	
}