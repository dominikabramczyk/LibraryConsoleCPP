#pragma once
#include "User.h"
#include <string>
using namespace std;

class Employee : public User
{
	
public:
	Employee(string n/*name*/, string s/*surename*/);
	void add_user();	
};

