#include "Student.h"
#include "User.h"
#include <string>
#include <iostream>
using namespace std;

string name1, surename1;
Student::Student(string na/*name*/, string su/*surename*/)
{
	name1 = na;
	surename1 = su;
};

void Student::add_user()
{
	cout << "\tWitaj w rejestracji studentow!\nPodaj imie: ";
	cin >> name1;
	cout << "Podaj nazwisko: ";
	cin >> surename1;
	cout << name1 << " " << surename1 << "Zostal zarejestrowany";
};
