#pragma once
#include "User.h"
#include <string>
#include <iostream>
using namespace std;

class Student :public User
{
public:
	Student(string na/*name*/, string su/*surename*/);
	void add_user();

};

