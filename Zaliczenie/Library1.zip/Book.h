#pragma once
#include <string>
using namespace std;

class Book
{
public:
	Book(string t/*title*/, int q/*quantity*/);
	void add_book();
	void rent_book();
	void return_book();
};

