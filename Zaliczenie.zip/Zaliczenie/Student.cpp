#include "Student.h"
#include "User.h"
#include <string>
#include <iostream>
using namespace std;


Student::Student(string n, string s, int a)
{
	Name = n;
	Surename = s;
	AlbumNumber = a;
	
};

