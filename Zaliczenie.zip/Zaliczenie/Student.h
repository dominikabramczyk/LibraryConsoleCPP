#pragma once
#include "User.h"
#include <string>
#include <iostream>
using namespace std;

class Student
{
public:

	string Name, Surename;
	int AlbumNumber;
	Student(string, string, int);

};

