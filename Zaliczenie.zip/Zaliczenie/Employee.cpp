#include "Employee.h"
#include "User.h"
#include <string>
#include <iostream>
using namespace std;

Employee::Employee(string n/*name*/, string s/*surename*/)
{
	Name = n;
	Surename = s;
};



 