#pragma once
class User
{
public:
	virtual void add_user() = 0; //czysta funkcja wirtualna
};

